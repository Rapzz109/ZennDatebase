module.exports = {
  BOT_TOKEN: "7842858543:AAESy88V3HrWbE3V4ZdHX9VyCuX-S3iUEtc", // Ganti jadi token bot lu
    allowedDevelopers: ['7491915541'], // Ganti jadi id telegram lu
};

/*/━━━━━━━━━━━━━━━━━━━━━━  
🔥 ZENN INFINITY 🔥  
━━━━━━━━━━━━━━━━━━━━━━  

🚀 Developer  : Rezi Official  
📢 Info       : @ReziiReal1
🛠️ Version    : 1.0  

🛡 Keamanan Script Ini 🛡
📌 Script Ini Menggunakan Database 🛡
📌 Enc Hard 🛡

⚠️ Jika Anda Tidak Membeli Script Ini, lebih Baik Tidak Usah Menggunakannya ⚠️
━━━━━━━━━━━━━━━━━/*/